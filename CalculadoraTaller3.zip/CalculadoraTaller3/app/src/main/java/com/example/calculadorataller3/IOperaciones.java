package com.example.calculadorataller3;

public interface IOperaciones {

    float suma(float a, float b);
    float resta(float a, float b);
    float multiplicacion(float a, float b);
    float division(float a, float b);
    void ingreseNumero(String num);
}
